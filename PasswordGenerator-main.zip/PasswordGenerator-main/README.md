# PasswordGenerator
Password_Generator
A simple password generator made as a Mini project using languages like HTML, CSS, JS.</br>
Minimum password length recommended for secure password is 8️ characters including letter🔡, numbers🔢 and symbols🔣.</br>
